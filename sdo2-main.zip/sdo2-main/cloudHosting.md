SAP Security Learning We detected that you are using AWS console but have not yet taken
the [Cloud Security Fundamentols](https://google.com) training. Did you know that if not using [BTP](https://google.com)
, SAP policy requires an exception approving the use of any cloud hosting services? For more information, review the
training on [Cloud Security Fundomentals](https://google.com), or reach out to your
local [Applicotion Security Lead](https://google.com)