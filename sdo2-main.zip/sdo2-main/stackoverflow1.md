This plugin correctly works in
https://github.com ,
https://www.codecademy.com ,
https://www.linkedin.com ,
https://aws.amazon.com ,
https://leetcode.com ,
https://learnxinyminutes.com ,
https://developer.mozilla.org ,
https://forum.freecodecamp.org ,
